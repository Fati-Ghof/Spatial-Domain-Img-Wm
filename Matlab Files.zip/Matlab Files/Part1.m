clc
clear all
close all
%Embedding and extracting SUTECH logo in fixed location
f=imread('flower.jpg');
l=imread('logo.JPG');
v=input('Enter your bit from (1 2...8):')

%convert RGB to Gray
f1=rgb2gray(f);
e1=rgb2gray(f);
%showing the original image
figure
imshow(f1,[min(f1(:)),max(f1(:))])
title('original image')
o=double(f1);
%convert RGB to Gray
l1=rgb2gray(l);
%convert Gray to binary
level = graythresh(l1);
bw = im2bw(l1,level);
size(f1);
figure
imshow(bw)
title('original logo')

%Embedding WM
for i=1:size(bw,1)
    for j=1:size(bw,2)
        d=bw(i,j);
        c=bitget(f1(220+i,220+j),v);
        s=bitand(1,d)
        f1(220+i,220+j)=bitset(f1(220+i,220+j),v,s);
    end
end
%showing the watermarked image
figure
imshow(f1,[min(f1(:)),max(f1(:))])
title('watermarked image')
% Calculating PSNR
mseimage=(double(f1)-double(e1)).^2;
mse=sum(sum(mseimage))/(size(f,1)*size(f,2));
PSNRwmimg=10*log10(255^2/mse)
%Extracting WM
for i=1:64
    for j=1:64
        wm(i,j)=bitget(f1(220+i,220+j),v);
    end
end
figure
imshow(wm,[min(wm(:)),max(wm(:))])
title('Extracted logo')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%showing effect of resizing
B = imresize(f1,0.5);
D= imresize(B,2);
for i=1:size(bw,1)
    for j=1:size(bw,2)
        wm1(i,j)=bitget(D(220+i,220+j),v);
    end
end
figure
imshow(D,[min(D(:)),max(D(:))])
title('resized image')

figure
imshow(wm1,[min(wm1(:)),max(wm1(:))])
%title('Extracted logo from resized image')
% Calculating PSNR
mseimage=(double(D)-double(e1)).^2;
mse=sum(sum(mseimage))/(512*512);
PSNRresizeimg=10*log10(255^2/mse)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%showing effect of rotating
z = imrotate(f1,1,'crop');
for i=1:size(bw,1)
    for j=1:size(bw,2)
        wm2(i,j)=bitget(z(220+i,220+j),v);
    end
end

figure
imshow(z,[min(z(:)),max(z(:))])
title('rotataed image')
figure
imshow(wm2,[min(wm2(:)),max(wm2(:))])
title('Extracted logo from rotated image')

% Calculating PSNR
mseimage=(double(z)-double(e1)).^2;
mse=sum(sum(mseimage))/(size(f,1)*size(f,2));
PSNRrotateimg=10*log10(255^2/mse)




