clc
clear all
close all
%Embedding and Extracting RANDOM logo in random location

% Generating a random logo
for i=1:30
    for j=1:30
        s=round(rand*63)+1;
        r=round(rand*63)+1;
        l1(r,s)=1;
    end
end
f=imread('flower.jpg');
v=input('Enter your bit:')

%convert RGB to Gray
f1=rgb2gray(f);
e1=rgb2gray(f);

%showing the original image
figure
imshow(f1,[min(f1(:)),max(f1(:))])
title('original image')
o=double(f1);

%convert Gray to binary
level = graythresh(l1);
bw = im2bw(l1,level); 
size(f1);
figure
imshow(bw)

%Embedding WM
title('original logo')
for i=1:size(bw,1)
    for j=1:size(bw,2)
    r = rand;
    a = rand;
    p(i,j)=round(r*511)+1;
    q(i,j)=round(a*511)+1;
    end
end



for i=1:size(bw,1)
    for j=1:size(bw,2)
         d=bw(i,j);
      c=bitget(f1(p(i,j),q(i,j)),v);
       s=bitand(1,d);
       f1(p(i,j),q(i,j))=bitset(f1(p(i,j),q(i,j)),v,s);
    end
end
figure
imshow(f1,[min(f1(:)),max(f1(:))])
title('watermarked image')

% Calculating PSNR
mseimage=(double(f1)-double(e1)).^2;
mse=sum(sum(mseimage))/(size(f,1)*size(f,2));
PSNR=10*log10(255^2/mse)

%Extracting WM
for i=1:size(bw,1)
    for j=1:size(bw,2)
        wm(i,j)=bitget(f1(p(i,j),q(i,j)),v);
    end
end
figure
imshow(wm,[min(wm(:)),max(wm(:))])
title('Extracted logo')

